CREATE TABLE expenses (
    expense_id          VARCHAR(20)  PRIMARY KEY,
    employee_id         VARCHAR(10)  NOT NULL,
    employee_name       VARCHAR(100) NOT NULL,
    company              VARCHAR(100),
    department           VARCHAR(50),
    cost_center          VARCHAR(20),
    expense_date         DATE,
    category              VARCHAR(50),
    description           VARCHAR(255),
    business_purpose      VARCHAR(255),
    project_code          VARCHAR(20),
    client_name           VARCHAR(100),
    billable               BOOLEAN,
    amount                 NUMERIC(10,2),
    tax_amount              NUMERIC(10,2),
    total_amount             NUMERIC(10,2),
    currency                  CHAR(3),
    payment_method             VARCHAR(30),
    receipt_attached            BOOLEAN,
    policy_compliant              BOOLEAN,
    expense_report_id              VARCHAR(30),
    submission_date                 DATE,
    approval_status                  VARCHAR(20),
    approved_by                       VARCHAR(100),
    approval_date                      DATE,
    notes                               TEXT
);

CREATE TABLE reimbursements (
    reimbursement_id       VARCHAR(20) PRIMARY KEY,
    expense_id              VARCHAR(20) NOT NULL REFERENCES expenses(expense_id),
    expense_report_id        VARCHAR(30),
    employee_id               VARCHAR(10) NOT NULL,
    employee_name              VARCHAR(100) NOT NULL,
    company                     VARCHAR(100),
    department                   VARCHAR(50),
    cost_center                   VARCHAR(20),
    approved_amount                NUMERIC(10,2),
    reimbursement_amount            NUMERIC(10,2),
    processing_fee                   NUMERIC(10,2),
    currency                          CHAR(3),
    transaction_id                     VARCHAR(20),
    bank_account_last4                  VARCHAR(4),
    reimbursement_date                   DATE,
    days_to_reimburse                     INTEGER,
    reimbursement_method                   VARCHAR(30),
    processed_by                            VARCHAR(100),
    status                                    VARCHAR(20),
    rejection_reason                          VARCHAR(255),
    notes                                      TEXT
);

select * from expenses;

select * from reimbursements;


Select expense_id from reimbursements;

/*
UPDATE reimbursements
SET status = 'TEST_CHANGE'
WHERE expense_id = 'EXP5006';

SELECT expense_id, status FROM reimbursements WHERE expense_id = 'EXP5006';


UPDATE reimbursements
SET status = 'Rejected'
WHERE expense_id = 'EXP5006';
*/

SELECT * FROM expenses WHERE approval_status = 'Approved';


SELECT expense_id, employee_name, total_amount
FROM expenses
ORDER BY total_amount DESC
LIMIT 5;


SELECT 
    Expense_ID, 
    Employee_ID, 
    Employee_Name, 
    Department, 
    Expense_Date, 
    Category, 
    Total_Amount, 
    Approval_Status
FROM expenses
WHERE Department = 'IT';


SELECT *
FROM expenses
WHERE Department = 'IT';


UPDATE public.expenses
SET category = 'Meals'
WHERE expense_id = 'EXP5001';


UPDATE public.expenses
SET category = 'Software'
WHERE expense_id = 'EXP5001';


UPDATE public.expenses
SET total_amount = '217.54'
WHERE expense_id = 'EXP5002';