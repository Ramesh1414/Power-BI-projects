CYBER-PHYSICAL OT ENTERPRISE DATASET v2  (SYNTHETIC)
=====================================================
All data is synthetically generated (seeded, reproducible). Firmware versions and CVE ids (SYN-CVE-*) are fictional.
Coverage: 2020-01-01 to 2026-10-15 (2026 is a partial year). 30,000 incident/security-event records, 150 assets, 10 facilities.
Records include minor events (Low/Medium hazard), which is why per-asset frequency is higher than major-incident counts.

STAR/SNOWFLAKE MODEL (all one-to-many, single direction, dimension -> fact)
  Dim_Date[date]                 -> Fact_Cyber_Physical_Incidents[incident_date]
  Dim_Facility[facility_id]      -> Dim_Industrial_Assets_Master[facility_id] -> Fact[asset_id]
  Dim_Firmware[firmware_id]      -> Dim_Industrial_Assets_Master[firmware_id]
  Dim_Threat_Vectors_Taxonomy[vector_id] -> Fact[vector_id]
  Dim_Threat_Actor[threat_actor_id]      -> Fact[threat_actor_id]
  Dim_Event_Campaign[event_id]           -> Fact[event_id]   (blank event_id = no campaign)
  Dim_Firmware <-> Bridge_Firmware_CVE <-> Dim_CVE ;  Dim_CVE[cve_id] -> Fact[exploited_cve_id]
  Fact_Targets_Benchmarks[facility_id, year] -> Dim_Facility (use for budget/SLA variance visuals)

CHANGES FROM v1
  + Dim_Facility, Dim_Firmware, Dim_CVE, Bridge_Firmware_CVE, Dim_Threat_Actor, Dim_Event_Campaign, Dim_Date, Fact_Targets_Benchmarks
  + Incident lifecycle: detected/contained/closed timestamps, status, detection method, root cause, MTTD/MTTC
  + Asset controls: network segment, internet-facing, MFA, segmentation, monitoring, patch status, last patch date
  + Insurance recovered and net loss; threat actor; exploited CVE and patch-available flag
  ~ Loss now scales with criticality, sector revenue, downtime, risk, severity (v1: nearly flat across groups)
  ~ Safety breach and cascade are probabilistic (v1: fully determined by severity / probability score)
  ~ Real-world patterns: seasonality, rising cyber trend, 7 named campaigns/events, regional/sector threat mix
  ~ Realistic per-vendor firmware (6 versions each) instead of 150 unique strings; installs now 1998-2022
  ~ recovery_time_hours replaces mean_time_to_recovery_hours; physical_security_score is now higher = better
  - Removed control_system_layer (duplicate of asset_category); region/country/coordinates moved to Dim_Facility
  - Row count reduced from 70,000 to 30,000 for realistic frequency

KNOWN LIMITATIONS
  Synthetic: relationships are designed in, not observed. Do not use for real-world benchmarking.
  Blank values are intentional only in: event_id, exploited_cve_id, patch_available_at_incident, contained_ts_utc,
  closed_ts_utc (Fact); patch_release_date (Dim_CVE). See Data_Dictionary.csv.
  2026 is partial: use Dim_Date[is_ytd_comparable] for like-for-like YTD comparisons.
