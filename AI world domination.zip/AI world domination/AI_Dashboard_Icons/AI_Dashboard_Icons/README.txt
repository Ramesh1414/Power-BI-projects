AI Usage Analysis Dashboard - icon pack
=======================================
23 line icons, each in 3 colours:
  olive  #5A5F46  use on white or sand tiles (default)
  white  #FFFFFF  use on dark olive buttons and active tabs
  tan    #BE9167  use as an accent

Folders
  svg/<colour>/   vector files (24x24 grid, 1.8 stroke) - best for Power BI (Insert > Image)
  png/<colour>/   256x256 transparent PNG
  images/         AI_Hero_Image.png (home page and page 1 hero)
  AI_Dashboard_Theme.json   Power BI theme (View > Themes > Browse for themes)
  icon_preview.png          all icons on one sheet

Where each icon is used
  home         Home tab
  bar-chart    AI Adoption tab and card
  briefcase    AI at Work tab and card, Professions Tracked KPI
  forecast     Jobs Forecast tab and card
  robot        Dashboard title, Task Automation KPI
  refresh      Last update date
  database     Data range, data tables note
  chip         Total Tools KPI, most-used tool row
  users        MAU KPI, Roles Tracked KPI, professions row
  dollar       Total Revenue KPI
  trend-up     Adoption KPIs, monthly growth row
  clock        Hours saved KPI and row
  calendar     Daily Use Share KPI
  alert        High-Risk Roles KPI, top 10 at risk row
  donut        MAU by category row
  globe        Country rows
  layers       Heat map row
  filter       Slicer tip
  pointer      Click-a-tab tip
  info         Synthetic data note
  arrow-right  Open page buttons
  shield       Spare: trust and control
  bulb         Spare: insights
